const path = require('path')
const { BrowserWindow } = require('electron')
const { getJanelaPrincipal } = require('./janelaPrincipal')
const { getJanelaUser } = require('./janelaPrincipal')
const { fromBuffer } = require('yauzl')



function criarJanelaModal(telaPai, arquivohtml) {
    const janela = new BrowserWindow({
        width: 1080,
        height: 720,

        modal: true,
        parent: telaPai,

        webPreferences: {
            preload: path.join(__dirname, 'preload.js')
        }

    })

    janela.loadFile(arquivohtml)

    return janela
}

function getJanelaAtiva() {
    return getJanelaPrincipal() || getJanelaUser()
}

function modalAbrirCategoria(event){
      let mainWindow = getJanelaAtiva()
    if (mainWindow) {
        criarJanelaModal(mainWindow, 'src/categoria/categoria.html')
    }
    else {
        console.warn('Janela modal não encontrada.')
    }
}

function modalAbrirTransacao(event){
      let mainWindow = getJanelaAtiva()
    if (mainWindow) {
        criarJanelaModal(mainWindow, 'src/transacao/transacao.html')
    }
    else {
        console.warn('Janela modal não encontrada.')
    }
}

function modalAbrirConta(event){
      let mainWindow = getJanelaAtiva()
    if (mainWindow) {
        criarJanelaModal(mainWindow, 'src/conta/conta.html')
    }
    else {
        console.warn('Janela modal não encontrada.')
    }
}

function modalAbrirUsuario(event){
    let mainWindow = getJanelaAtiva()
    if (mainWindow) {
        criarJanelaModal(mainWindow, 'src/usuario/usuario.html')
    }
    else {
        console.warn('Janela modal não encontrada.')
    }
}


module.exports = {
    criarJanelaModal,
    modalAbrirCategoria,
    modalAbrirTransacao,
    modalAbrirConta,
    modalAbrirUsuario

}
