const path = require('path')
const { BrowserWindow } = require('electron')

let janelaAdmin
let janelaUser
let janelaLogin

function createAdminWindow() {
    janelaAdmin = new BrowserWindow({
        width: 1080,
        height: 720,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js')
        }
    })

    janelaAdmin.loadFile('index.html')

    janelaAdmin.on('closed', () => {
        janelaAdmin = null
    })

    
   
    janelaLogin.close()
    return janelaAdmin

    
}

function createUserWindow() {
    janelaUser = new BrowserWindow({
        width: 1080,
        height: 720,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js')
        }
    })

    janelaUser.loadFile('user.html')

    janelaUser.on('closed', () => {
        janelaUser = null
    })

     janelaLogin.close()
    return janelaUser

}

function createLoginWindow() {
    janelaLogin = new BrowserWindow({
        width: 600,
        height: 500,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js')
        }
    })

    janelaLogin.loadFile('src/login/login.html')

    janelaLogin.on('closed', () => {
        janelaLogin = null
    })

}





function getJanelaPrincipal() {
    return janelaAdmin
}

function getJanelaUser() {
    return janelaUser
}

function getJanelaLogin() {
    return janelaLogin
}

module.exports = {
    createAdminWindow,
    getJanelaPrincipal,
    createLoginWindow,
    getJanelaLogin,
    createUserWindow,
    getJanelaUser
}