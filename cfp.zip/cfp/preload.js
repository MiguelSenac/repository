const {contextBridge, ipcRenderer} = require('electron')

function listarCategorias(usuario_id, usuario_tipo) {
    return ipcRenderer.invoke('categoria-listar', usuario_id, usuario_tipo)
}

function criarCategoria(nome, usuario_id) {
    return ipcRenderer.invoke('categoria-criar', nome, usuario_id)
}

function atualizarCategoria(id, nome, usuario_id) {
    return ipcRenderer.invoke('categoria-atualizar', id, nome, usuario_id)
}

function excluirCategoria(id, usuario_id) {
    return ipcRenderer.invoke('categoria-excluir', id, usuario_id)
}

function listarContas(usuario_id, usuario_tipo) {
    return ipcRenderer.invoke('conta-listar', usuario_id, usuario_tipo)
}

function criarConta(nome, saldo, usuario_id) {
    return ipcRenderer.invoke('conta-criar', nome, saldo, usuario_id)
}

function atualizarConta(id, nome) {
    return ipcRenderer.invoke('conta-atualizar', id, nome)
}

function excluirConta(id) {
    return ipcRenderer.invoke('conta-excluir', id)
}

function listarTransacoes(usuario_id, usuario_tipo) {
    return ipcRenderer.invoke('transacao-listar', usuario_id, usuario_tipo)
}

function criarTransacao(descricao, valor, data, tipo, categoriaId, contaId, usuario_id) {
    return ipcRenderer.invoke('transacao-criar', descricao, valor, data, tipo, categoriaId, contaId, usuario_id)
}

function atualizarTransacao(id, descricao, valor, data, tipo, categoriaId, contaId) {
    return ipcRenderer.invoke('transacao-atualizar', id, descricao, valor, data, tipo, categoriaId, contaId)
}

function excluirTransacao(id) {
    return ipcRenderer.invoke('transacao-excluir', id)
}

function buscarTransacoesPorIdConta(id, usuario_id) {
    return ipcRenderer.invoke('buscar-transacoes-por-id-conta', id, usuario_id)
}

function validarLogin(email, senha) {
    return ipcRenderer.invoke('validar-login', email, senha)
}

function cadastrarUsuario(email, senha, nome) {
    return ipcRenderer.invoke('cadastrar-usuario', email, senha, nome)
}

function listarUsuarios() {
    return ipcRenderer.invoke('usuario-listar');
}
function criarUsuario(email, senha, nome, tipo) {
    return ipcRenderer.invoke('usuario-criar', email, senha, nome, tipo);
}
function atualizarUsuario(id, email, senha, nome, tipo) {
    return ipcRenderer.invoke('usuario-atualizar', id, email, senha, nome, tipo);
}
function excluirUsuario(id) {
    return ipcRenderer.invoke('usuario-excluir', id);
}


contextBridge.exposeInMainWorld('financasAPI', {
    listarCategorias,
    criarCategoria,
    atualizarCategoria,
    excluirCategoria,
    listarContas,
    criarConta,
    atualizarConta,
    excluirConta,
    listarTransacoes,
    criarTransacao,
    atualizarTransacao,
    excluirTransacao,
    buscarTransacoesPorIdConta,
    validarLogin,
    cadastrarUsuario,
    listarUsuarios,
    criarUsuario,
    atualizarUsuario,
    excluirUsuario
})

function modalAbrirCategoria() {
    ipcRenderer.send('modal-abrir-categoria')
}

function modalAbrirTransacao() {
    ipcRenderer.send('modal-abrir-transacao')
}

function modalAbrirConta() {
    ipcRenderer.send('modal-abrir-conta')
}

function modalAbrirUsuario() {
    ipcRenderer.send('modal-abrir-usuario')
}

function createAdminWindow() {
    ipcRenderer.send('janela-admin-criar')
}

function createUserWindow() {
    ipcRenderer.send('janela-user-criar')
}

contextBridge.exposeInMainWorld('janelaAPI', {
    modalAbrirCategoria,
    modalAbrirTransacao,
    modalAbrirConta,
    modalAbrirUsuario,
    createAdminWindow,
    createUserWindow
})