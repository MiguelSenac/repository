var tabelaUsuarios = document.getElementById('usuariosTableDados');
var modal = document.getElementById('modal');
var inputId = document.getElementById('usuario-id');
var inputEmail = document.getElementById('usuario-email');
var inputSenha = document.getElementById('usuario-senha');
var inputNome = document.getElementById('usuario-nome');
var inputTipo = document.getElementById('usuario-tipo');
var btnSalvar = document.getElementById('btn-salvar');
var btnExcluir = document.getElementById('btn-excluir');
var btnLimpar = document.getElementById('btn-limpar');

btnLimpar.addEventListener('click', limpar);

function limpar() {
    inputId.value = '';
    inputEmail.value = '';
    inputSenha.value = '';
    inputNome.value = '';
    inputTipo.value = 'user';
}

btnSalvar.addEventListener('click', adicionarAlterarUsuario);
async function adicionarAlterarUsuario() {
    if (inputId.value != "") {
        await alterarUsuario();
    } else {
        await adicionarUsuario();
    }
}

async function alterarUsuario() {
    await window.financasAPI.atualizarUsuario(
        Number(inputId.value),
        inputEmail.value,
        inputSenha.value,
        inputNome.value,
        inputTipo.value
    );
    await carregarUsuarios();
    limpar();
}

async function adicionarUsuario() {
    await window.financasAPI.criarUsuario(
        inputEmail.value,
        inputSenha.value,
        inputNome.value,
        inputTipo.value
    );
    await carregarUsuarios();
    limpar();
}

btnExcluir.addEventListener('click', excluirUsuario);
async function excluirUsuario() {
    await window.financasAPI.excluirUsuario(Number(inputId.value));
    await carregarUsuarios();
    limpar();
}

function mostrarModalUsuario(id, email, senha, nome, tipo) {
    inputId.value = id || '';
    inputEmail.value = email || '';
    inputSenha.value = senha || '';
    inputNome.value = nome || '';
    inputTipo.value = tipo || 'user';
    modal.style.display = 'block';
    lucide.createIcons();
}

function criarLinhaUsuario(usuario) {
    var linha = document.createElement('tr');

    var celulaEmail = document.createElement('td');
    celulaEmail.textContent = usuario.email;
    linha.appendChild(celulaEmail);

    var celulaNome = document.createElement('td');
    celulaNome.textContent = usuario.nome;
    linha.appendChild(celulaNome);

    var celulaTipo = document.createElement('td');
    celulaTipo.textContent = usuario.tipo;
    linha.appendChild(celulaTipo);

    var celulaEditar = document.createElement('td');
    var botao = document.createElement('button');
    var icone = document.createElement('i');
    icone.setAttribute('data-lucide', 'edit');
    botao.appendChild(icone);
    botao.addEventListener('click', function () {
        mostrarModalUsuario(usuario.id, usuario.email, usuario.senha, usuario.nome, usuario.tipo);
    });
    celulaEditar.appendChild(botao);
    linha.appendChild(celulaEditar);

    tabelaUsuarios.appendChild(linha);
}

async function carregarUsuarios() {
    criarCabecalhoUsuarios();
    const usuarios = await window.financasAPI.listarUsuarios();
    tabelaUsuarios.innerHTML = '';
    usuarios.forEach(criarLinhaUsuario);
    lucide.createIcons();
}

function criarCabecalhoUsuarios() {
    const cabecalho = document.getElementById('usuariosTableCabecalho');
    cabecalho.innerHTML = '';

    const tr = document.createElement('tr');

    const thEmail = document.createElement('th');
    thEmail.textContent = 'Email';
    tr.appendChild(thEmail);

    const thNome = document.createElement('th');
    thNome.textContent = 'Nome';
    tr.appendChild(thNome);

    const thTipo = document.createElement('th');
    thTipo.textContent = 'Tipo';
    tr.appendChild(thTipo);

    const thEditar = document.createElement('th');
    thEditar.textContent = 'Editar';
    tr.appendChild(thEditar);

    cabecalho.appendChild(tr);
}

carregarUsuarios();