const db = require('../../db')

async function listarUsuarios() {
    const resultado = await db.query('SELECT * FROM usuarios');
    return resultado.rows;
}

async function criarUsuario(event, email, senha, nome, tipo) {
    const resultado = await db.query(
        "INSERT INTO usuarios (email, senha, nome, tipo) VALUES ($1, $2, $3, $4) RETURNING *",
        [email, senha, nome, tipo]
    );
    return resultado.rows;
}

async function atualizarUsuario(event, id, email, senha, nome, tipo) {
    const resultado = await db.query(
        "UPDATE usuarios SET email = $1, senha = $2, nome = $3, tipo = $4 WHERE id = $5 RETURNING *",
        [email, senha, nome, tipo, id]
    );
    return resultado.rows;
}

async function excluirUsuario(event, id) {
    const resultado = await db.query(
        "DELETE FROM usuarios WHERE id = $1 RETURNING *",
        [id]
    );
    return resultado.rows;
}

module.exports = {
    listarUsuarios,
    criarUsuario,
    atualizarUsuario,
    excluirUsuario
}