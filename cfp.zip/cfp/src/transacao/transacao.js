flatpickr("#transacao-data", {
    dateFormat: "d/m/Y",
    locale: "pt"
})
const tabelaTransacoes = document.getElementById('transacoesTableDados')
const botaoLimpar = document.getElementById('btn-limpar')
const modalIDTransacao = document.getElementById('transacao-id')
const modalDescricaoTransacao = document.getElementById('transacao-descricao')
const modalValorTransacao = document.getElementById('transacao-valor')
const modalDataTransacao = document.getElementById('transacao-data')
const modalTipoTransacao = document.getElementById('transacao-tipo')
const modalCategoriaTransacao = document.getElementById('transacao-categoria')
const modalContaTransacao = document.getElementById('transacao-conta')
const botaoSalvar = document.getElementById('btn-salvar')
const botaoExcluir = document.getElementById('btn-excluir')
const botaoFiltrar = document.getElementById('btn-filtrar')
const modalFiltrar = document.getElementById('conta-filtro')

const usuario_id = window.localStorage.getItem('usuario_id')
const usuario_tipo = window.localStorage.getItem('usuario_tipo')

botaoFiltrar.addEventListener('click', buscarContaPorID)

botaoSalvar.addEventListener('click', adicionarAlterarTransacao)

botaoExcluir.addEventListener('click', excluirTransacao)

botaoLimpar.addEventListener('click', limpar)

function mostrarDetalhes(descricao, valor, data, tipo, categoria, conta, id) {
    modalIDTransacao.value = id
    modalDescricaoTransacao.value = descricao
    modalValorTransacao.value = Number(valor).toFixed().replace('.', ',')
    // Desabilita o campo valor ao editar
    if (id) {
        modalValorTransacao.disabled = true
    } else {
        modalValorTransacao.disabled = false
    }
    // Data formatada
    if (data) {
        const d = new Date(data)
        modalDataTransacao.value = d.toLocaleDateString('pt-BR')
    } else {
        modalDataTransacao.value = ''
    }
    modalTipoTransacao.value = tipo
    modalCategoriaTransacao.value = categoria
    modalContaTransacao.value = conta
}

function limpar() {
    modalIDTransacao.value = ''
    modalDescricaoTransacao.value = ''
    modalValorTransacao.value = ''
    modalDataTransacao.value = ''
    modalTipoTransacao.value = ''
    modalCategoriaTransacao.value = ''
    modalContaTransacao.value = ''
    modalValorTransacao.disabled = false
}

async function adicionarAlterarTransacao() {
    if (modalIDTransacao.value != "") {
        await alterarTransacao()
    }
    else {
        await adicionarTransacao()
    }
}

async function alterarTransacao() {
    await window.financasAPI.atualizarTransacao(
        modalIDTransacao.value,                  // id
        modalDescricaoTransacao.value,           // descricao
        Number(modalValorTransacao.value.replace(',', '.')), // valor
        modalDataTransacao.value,                // data
        modalTipoTransacao.value,                // tipo
        modalCategoriaTransacao.value,           // categoria_id
        modalContaTransacao.value                // conta_id
    )

    carregarTransacoes()
    limpar()
}






async function adicionarTransacao() {
    await window.financasAPI.criarTransacao(
        modalDescricaoTransacao.value,
        Number(modalValorTransacao.value.replace(',', '.')),
        modalDataTransacao.value,
        modalTipoTransacao.value,
        modalCategoriaTransacao.value,
        modalContaTransacao.value,
        usuario_id
    )
    carregarTransacoes()
    limpar()
}

async function excluirTransacao() {
    await window.financasAPI.excluirTransacao(modalIDTransacao.value)
    carregarTransacoes()
    limpar()
}

async function carregarTransacoes() {
    criarCabecalhoTransacoes()
    const transacoes = await window.financasAPI.listarTransacoes(usuario_id, usuario_tipo)
    tabelaTransacoes.innerHTML = ''

    transacoes.forEach(criarLinhaTransacao)

    lucide.createIcons()
    listarCategorias()
    listarContas()
    listarContasFiltradas()
}

async function criarLinhaTransacao(transacao) {
    const linha = document.createElement('tr')

    if(usuario_tipo == 'admin'){
        const celulaUsuario = document.createElement('td')
        celulaUsuario.textContent = transacao.usuario_nome
        linha.appendChild(celulaUsuario)

    }
    
    const celulaDescricao = document.createElement('td')
    celulaDescricao.textContent = transacao.descricao
    linha.appendChild(celulaDescricao)

    const celulaValor = document.createElement('td')
    celulaValor.textContent = Number(transacao.valor).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
        .replace('R$ ', 'R$')
    linha.appendChild(celulaValor)

    const celulaData = document.createElement('td')
    celulaData.textContent = formatarData(transacao.data)
    linha.appendChild(celulaData)

    const celulaTipo = document.createElement('td')

    const tipoFormatado = transacao.tipo.charAt(0).toUpperCase() + transacao.tipo.slice(1)
    celulaTipo.textContent = tipoFormatado
    celulaTipo.style.color = transacao.tipo === 'entrada' ? '#4caf50' : '#e53935'
    linha.appendChild(celulaTipo)

    const celulaCategoria = document.createElement('td')
    celulaCategoria.textContent = await buscarNomeCategoria(transacao.categoria_id)
    linha.appendChild(celulaCategoria)

    const celulaConta = document.createElement('td')
    celulaConta.textContent = await buscarNomeConta(transacao.conta_id)
    linha.appendChild(celulaConta)

    const celulaBotao = document.createElement('td')
    const botao = document.createElement('button')
    botao.addEventListener('click', function () {
        mostrarDetalhes(
            transacao.descricao,
            transacao.valor,
            transacao.data,
            transacao.tipo,
            transacao.categoria_id,
            transacao.conta_id,
            transacao.id)
    })

    const icone = document.createElement('i')
    icone.setAttribute('data-lucide', 'edit')
    botao.appendChild(icone)
    celulaBotao.appendChild(botao)
    linha.appendChild(celulaBotao)
    tabelaTransacoes.appendChild(linha)
    lucide.createIcons()
}


async function buscarNomeCategoria(id) {
    const variavel = await window.financasAPI.listarCategorias(usuario_id, usuario_tipo);
    for (let i = 0; i < variavel.length; i++) {
        if (variavel[i].id === id) {
            return variavel[i].nome;
        }
    }
}

async function buscarNomeConta(id) {
    const variavel = await window.financasAPI.listarContas(usuario_id, usuario_tipo);
    for (let i = 0; i < variavel.length; i++) {
        if (variavel[i].id === id) {
            return variavel[i].nome;
        }
    }
}

async function listarCategorias() {
    const usuario_id = window.localStorage.getItem('usuario_id')
    const categorias = await window.financasAPI.listarCategorias(usuario_id, usuario_tipo);
    modalCategoriaTransacao.innerHTML = '';
    const optionVazia = document.createElement('option');
    optionVazia.value = '';
    optionVazia.textContent = 'Selecione uma categoria';
    optionVazia.disabled = true;
    optionVazia.selected = true;
    modalCategoriaTransacao.appendChild(optionVazia);

    categorias.forEach(mostrarDetalhesCategoria);
}
function mostrarDetalhesCategoria(categoria) {
    const option = document.createElement('option');
    option.value = categoria.id;
    option.textContent = categoria.nome;
    modalCategoriaTransacao.appendChild(option);
}

async function listarContas() {
    const usuario_id = window.localStorage.getItem('usuario_id')
    const contas = await window.financasAPI.listarContas(usuario_id, usuario_tipo);
    modalContaTransacao.innerHTML = '';
    const optionVazia = document.createElement('option');
    optionVazia.value = '';
    optionVazia.textContent = 'Selecione uma conta';
    optionVazia.disabled = true;
    optionVazia.selected = true;
    modalContaTransacao.appendChild(optionVazia);

    contas.forEach(mostrarDetalhesConta);
}
function mostrarDetalhesConta(conta) {
    const option = document.createElement('option');
    option.value = conta.id;
    option.textContent = conta.nome;
    modalContaTransacao.appendChild(option);
}

function formatarData(dataString) {
    if (!dataString) return ''
    const d = new Date(dataString)
    const dia = String(d.getDate()).padStart(2, '0')
    const mes = String(d.getMonth() + 1).padStart(2, '0')
    const ano = d.getFullYear()
    return `${dia}/${mes}/${ano}`
}


function filtrarContas(linha) {
    const option = document.createElement('option')
    option.value = linha.id
    option.textContent = linha.nome
    modalFiltrar.appendChild(option)
}

async function listarContasFiltradas() {
    const usuario_id = window.localStorage.getItem('usuario_id')
    const contas = await window.financasAPI.listarContas(usuario_id, usuario_tipo)
    modalFiltrar.innerHTML = ''
    const optionVazia = document.createElement('option')
    optionVazia.value = '';
    optionVazia.textContent = 'Filtre por uma conta'
    modalFiltrar.append(optionVazia)
    contas.forEach(filtrarContas)
}



async function buscarContaPorID() {
    if (modalFiltrar.value != '') {
        tabelaTransacoes.innerHTML = ''
        var transacoes = await window.financasAPI.buscarTransacoesPorIdConta(modalFiltrar.value, usuario_id)
        for (var i = 0; i < transacoes.length; i++) {
            await criarLinhaTransacao(transacoes[i])
        }
        lucide.createIcons()
    }
    else {
        carregarTransacoes()
    }

}

function criarCabecalhoTransacoes() {
    const cabecalho = document.getElementById('transacoesTableCabecalho');
    cabecalho.innerHTML = ''

    const tr = document.createElement('tr')

    if (usuario_tipo === 'admin') {
        const thUsuario = document.createElement('th')
        thUsuario.textContent = 'Titular'
        tr.appendChild(thUsuario)
    }

    const thDescricao = document.createElement('th')
    thDescricao.textContent = 'Descrição'
    tr.appendChild(thDescricao)

    const thValor = document.createElement('th')
    thValor.textContent = 'Valor'
    tr.appendChild(thValor)

    const thData = document.createElement('th')
    thData.textContent = 'Data'
    tr.appendChild(thData)

    const thTipo = document.createElement('th')
    thTipo.textContent = 'Tipo'
    tr.appendChild(thTipo)

    const thCategoria = document.createElement('th')
    thCategoria.textContent = 'Categoria'
    tr.appendChild(thCategoria)

    const thConta = document.createElement('th')
    thConta.textContent = 'Conta'
    tr.appendChild(thConta)

    const thEditar = document.createElement('th')
    thEditar.textContent = 'Editar'
    tr.appendChild(thEditar)

    cabecalho.appendChild(tr)
}

carregarTransacoes()
