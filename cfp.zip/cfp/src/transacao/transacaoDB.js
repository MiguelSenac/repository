const db = require('../../db')

async function listarTransacoes(event, usuario_id, usuario_tipo) {
    let resultado
    if(usuario_tipo === 'admin') {
        resultado = await db.query('SELECT transacoes.*, usuarios.nome AS usuario_nome FROM transacoes JOIN usuarios ON transacoes.usuario_id = usuarios.id')
    }
    else {
        resultado = await db.query('SELECT * FROM transacoes WHERE usuario_id = $1', [usuario_id])
    }
    return resultado.rows
}

async function criarTransacao(event, descricao, valor, data, tipo, categoria_id, conta_id, usuario_id) {
    // Insere a transação no banco
    const resultado = await db.query(
        "INSERT INTO transacoes (descricao, valor, data, tipo, categoria_id, conta_id, usuario_id) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *",
        [descricao, valor, data, tipo, categoria_id, conta_id, usuario_id]
    )

    // Atualiza o saldo da conta
    var operador
    if (tipo === 'entrada') {
        operador = '+'
    } else {
        operador = '-'
    }

    await db.query(
        "UPDATE contas SET saldo = saldo " + operador + " $1 WHERE id = $2",
        [valor, conta_id]
    )

    return resultado.rows
}

async function atualizarTransacao(event, id, descricao, valor, data, tipo, categoria_id, conta_id) {
    // Busca os dados antigos da transação
    const antiga = await db.query("SELECT valor, tipo, conta_id FROM transacoes WHERE id = $1", [id])
    if (antiga.rows.length === 0) {
        return []
    }

    var valorAntigo = antiga.rows[0].valor
    var tipoAntigo = antiga.rows[0].tipo
    var contaAntiga = antiga.rows[0].conta_id

    // Desfaz o efeito antigo no saldo da conta
    var operadorDesfazer
    if (tipoAntigo === 'entrada') {
        operadorDesfazer = '-'
    } else {
        operadorDesfazer = '+'
    }

    await db.query(
        "UPDATE contas SET saldo = saldo " + operadorDesfazer + " $1 WHERE id = $2",
        [valorAntigo, contaAntiga]
    )

    // Aplica o novo efeito no saldo da conta
    var operadorNovo
    if (tipo === 'entrada') {
        operadorNovo = '+'
    } else {
        operadorNovo = '-'
    }

    await db.query(
        "UPDATE contas SET saldo = saldo " + operadorNovo + " $1 WHERE id = $2",
        [valor, conta_id]
    )

    // Atualiza a transação no banco
    const resultado = await db.query(
        "UPDATE transacoes SET descricao = $1, valor = $2, data = $3, tipo = $4, categoria_id = $5, conta_id = $6 WHERE id = $7 RETURNING *",
        [descricao, valor, data, tipo, categoria_id, conta_id, id]
    )

    return resultado.rows
}

async function excluirTransacao(event, id) {
    // Busca os dados antigos da transação
    const antiga = await db.query("SELECT valor, tipo, conta_id FROM transacoes WHERE id = $1", [id])
    if (antiga.rows.length === 0) {
        return []
    }

    var valor = antiga.rows[0].valor
    var tipo = antiga.rows[0].tipo
    var conta_id = antiga.rows[0].conta_id

    // Desfaz o efeito no saldo da conta
    var operador
    if (tipo === 'entrada') {
        operador = '-'
    } else {
        operador = '+'
    }

    await db.query(
        "UPDATE contas SET saldo = saldo " + operador + " $1 WHERE id = $2",
        [valor, conta_id]
    )

    // Exclui a transação
    const resultado = await db.query("DELETE FROM transacoes WHERE id = $1 RETURNING *", [id])
    return
}

async function buscarTransacoesPorIdConta(event, id, usuario_id) {
    const resultado = await db.query('SELECT * FROM transacoes WHERE conta_id = $1 AND usuario_id = $2 ', [id, usuario_id])
    return resultado.rows
    
}


module.exports = {
    listarTransacoes,
    criarTransacao,
    atualizarTransacao,
    excluirTransacao,
    buscarTransacoesPorIdConta
}