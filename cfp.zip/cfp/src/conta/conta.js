var tabelaContas = document.getElementById('contasTableDados')
var modal = document.getElementById('modal')
var inputId = document.getElementById('conta-id')
var inputNome = document.getElementById('conta-nome')
var inputSaldo = document.getElementById('conta-saldo')
var btnSalvar = document.getElementById('btn-salvar')
var btnExcluir = document.getElementById('btn-excluir')
var btnLimpar = document.getElementById('btn-limpar')

const usuario_id = window.localStorage.getItem('usuario_id')
const usuario_tipo = window.localStorage.getItem('usuario_tipo')

if (usuario_tipo !== 'admin') {
    btnExcluir.disable = true   
}

btnLimpar.addEventListener('click', limpar)

 function limpar() {
    inputId.value = ''
    inputNome.value = ''
    inputSaldo.value = ''
    console.log(usuario_id)
}


btnSalvar.addEventListener('click', adicionarAlterarConta)
async function adicionarAlterarConta() {
    if (inputId.value != "") {
        await alterarConta()
    }
    else {
        await adicionarConta()

    }
}

async function alterarConta() {
    await window.financasAPI.atualizarConta(Number(inputId.value), inputNome.value, Number(inputSaldo.value.replace('R$', '').replace('.', '').replace(',', '.')))
    carregarContas()
    limpar()
}

async function adicionarConta() {
    console.log('usuario_id:', usuario_id, typeof usuario_id)
    await window.financasAPI.criarConta(inputNome.value, 0, usuario_id)
    carregarContas()
    limpar()
}


btnExcluir.addEventListener('click', excluirConta)



async function excluirConta() {
    await window.financasAPI.excluirConta(inputId.value)
    carregarContas()
    limpar()
}








function mostrarDetalhesConta(id, nome, saldo) {
    inputId.value = id
    inputNome.value = nome
    inputSaldo.value = Number(saldo).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
    modal.style.display = 'block'
    lucide.createIcons()
}

function criarLinhaConta(conta) {
    var linha = document.createElement('tr')

    if (usuario_tipo === 'admin') {
        var celulaUsuario = document.createElement('td')
        celulaUsuario.textContent = conta.usuario_nome
        linha.appendChild(celulaUsuario)
    }
    

    var celulaId = document.createElement('td')
    celulaId.textContent = conta.id
    linha.appendChild(celulaId)

    var celulaNome = document.createElement('td')
    celulaNome.textContent = conta.nome
    linha.appendChild(celulaNome)

    var celulaSaldo = document.createElement('td')
    celulaSaldo.textContent = Number(conta.saldo).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
    linha.appendChild(celulaSaldo)

    linha.addEventListener('click', function () {
        mostrarDetalhesConta(conta.id, conta.nome, conta.saldo)
    })

    const celulaBotao = document.createElement('td')
    const botaoEditar = document.createElement('button')
    botaoEditar.addEventListener('click', function () {
        mostrarDetalhesConta(
            conta.id,
            conta.nome,
            conta.saldo)
    })

    botaoEditar.textContent = ''

    const incone = document.createElement('i')
    incone.setAttribute('data-lucide', 'edit')
    botaoEditar.appendChild(incone)
    celulaBotao.appendChild(botaoEditar)
    linha.appendChild(celulaBotao)
    tabelaContas.appendChild(linha)
}

async function carregarContas() {
    criarCabecalhoContas()
    
    const contas = await window.financasAPI.listarContas(usuario_id, usuario_tipo)
    tabelaContas.innerHTML = ''

    contas.forEach(criarLinhaConta)

    lucide.createIcons()
}

function criarCabecalhoContas() {
    const cabecalho = document.getElementById('contasTableCabecalho');
    cabecalho.innerHTML = '';

    const tr = document.createElement('tr');

    if (usuario_tipo === 'admin') {
        const thTitular = document.createElement('th');
        thTitular.textContent = 'Titular';
        tr.appendChild(thTitular);
    }

    const thId = document.createElement('th');
    thId.textContent = 'ID';
    tr.appendChild(thId);

    const thNome = document.createElement('th');
    thNome.textContent = 'Nome';
    tr.appendChild(thNome);

    const thSaldo = document.createElement('th');
    thSaldo.textContent = 'Saldo';
    tr.appendChild(thSaldo);

    const thEditar = document.createElement('th');
    thEditar.textContent = 'Editar';
    tr.appendChild(thEditar);

    cabecalho.appendChild(tr);
}


carregarContas()