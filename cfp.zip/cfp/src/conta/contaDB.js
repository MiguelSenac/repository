const db = require('../../db')

async function listarContas(event, usuario_id, usuario_tipo) {
    let resultado
    if (usuario_tipo === 'admin') {
        resultado = await db.query(' SELECT contas.*, usuarios.nome AS usuario_nome FROM contas JOIN usuarios ON contas.usuario_id = usuarios.id')
    }
    else {
        resultado = await db.query('SELECT * FROM contas WHERE usuario_id = $1', [usuario_id])
    }
    return resultado.rows
}

async function criarConta(event, nome, saldo, usuario_id) {
     console.log('NOME:', nome, 'SALDO:', saldo, 'USUARIO_ID:', usuario_id)
    const resultado = await db.query("INSERT INTO contas (nome, saldo, usuario_id) VALUES ($1, $2, $3) RETURNING *", [nome, saldo, usuario_id])
    return resultado.rows
}

async function atualizarConta(event, id, nome, saldo) {
    const resultado = await db.query("UPDATE contas SET nome = $1, saldo = $2 WHERE id = $3 RETURNING *", [nome, saldo, id])
    return resultado.rows
}

async function excluirConta(event, id) {
    const resultado = await db.query("DELETE FROM contas WHERE id = $1 RETURNING *", [id])
    return resultado.rows
}

module.exports = {
    listarContas,
    criarConta,
    atualizarConta,
    excluirConta
}