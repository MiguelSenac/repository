var tabelaCategorias = document.getElementById('categoriasTableDados')
var modal = document.getElementById('modal')
var inputId = document.getElementById('categoria-id')
var inputNome = document.getElementById('categoria-nome')
var btnSalvar = document.getElementById('btn-salvar')
var btnExcluir = document.getElementById('btn-excluir')
var btnLimpar = document.getElementById('btn-limpar')

const usuario_id = window.localStorage.getItem('usuario_id')
const usuario_tipo = window.localStorage.getItem('usuario_tipo')

btnLimpar.addEventListener('click', limpar)

function limpar() {
    inputId.value = ''
    inputNome.value = ''
}

btnSalvar.addEventListener('click', adicionarAlterarCategoria)
async function adicionarAlterarCategoria() {
    if (inputId.value != "") {
        await alterarCategoria()
    } else {
        await adicionarCategoria()
    }
}

async function alterarCategoria() {
    await window.financasAPI.atualizarCategoria(Number(inputId.value), inputNome.value, usuario_id)
    await carregarCategorias()
    limpar()
}

async function adicionarCategoria() {
    await window.financasAPI.criarCategoria(inputNome.value, usuario_id)
    await carregarCategorias()
    limpar()
}

btnExcluir.addEventListener('click', excluirCategoria)
async function excluirCategoria() {
    await window.financasAPI.excluirCategoria(Number(inputId.value), usuario_id)
    await carregarCategorias()
    limpar()
}

function mostrarModalCategoria(id, nome) {
    inputId.value = id || ''
    inputNome.value = nome || ''
    modal.style.display = 'block'
    lucide.createIcons()
}

function criarLinhaCategoria(categoria) {
    var linha = document.createElement('tr')

    if (usuario_tipo == 'admin') {
    const celulaUsuario = document.createElement('td')
    celulaUsuario.textContent = categoria.usuario_nome
    linha.appendChild(celulaUsuario)
}

    var celulaNome = document.createElement('td')
    celulaNome.textContent = categoria.nome
    linha.appendChild(celulaNome)

    var celulaEditar = document.createElement('td')
    var botao = document.createElement('button')
    var icone = document.createElement('i')
    icone.setAttribute('data-lucide', 'edit')
    botao.appendChild(icone)
    botao.addEventListener('click', function () {
        mostrarModalCategoria(categoria.id, categoria.nome)
    })
    celulaEditar.appendChild(botao)
    linha.appendChild(celulaEditar)

    tabelaCategorias.appendChild(linha)
}

async function carregarCategorias() {
    criarCabecalhoCategorias()
    const categorias = await window.financasAPI.listarCategorias(usuario_id, usuario_tipo)
    tabelaCategorias.innerHTML = ''
    categorias.forEach(criarLinhaCategoria)
    lucide.createIcons()
}


function criarCabecalhoCategorias() {
    const cabecalho = document.getElementById('categoriasTableCabecalho');
    cabecalho.innerHTML = '';

    const tr = document.createElement('tr');

    if (usuario_tipo === 'admin') {
        const thUsuario = document.createElement('th');
        thUsuario.textContent = 'Titular';
        tr.appendChild(thUsuario);
    }

    const thNome = document.createElement('th');
    thNome.textContent = 'Nome';
    tr.appendChild(thNome);

    const thEditar = document.createElement('th');
    thEditar.textContent = 'Editar';
    tr.appendChild(thEditar);

    cabecalho.appendChild(tr);
}

carregarCategorias()