const db = require('../../db')

async function listarCategorias(event, usuario_id, usuario_tipo) {
    let resultado
    if (usuario_tipo === 'admin') {
        resultado = await db.query('SELECT categorias.*, usuarios.nome AS usuario_nome FROM categorias JOIN usuarios ON categorias.usuario_id = usuarios.id')
    }
    else {
        resultado = await db.query('SELECT * FROM categorias WHERE usuario_id = $1', [usuario_id])
    }
    return resultado.rows
}

async function criarCategoria(event, nome, usuario_id) {
    const resultado = await db.query(
        "INSERT INTO categorias (nome, usuario_id) VALUES ($1, $2) RETURNING *",
        [nome, usuario_id]
    )
    return resultado.rows
}

async function atualizarCategoria(event, id, nome, usuario_id) {
    const resultado = await db.query(
        "UPDATE categorias SET nome = $1 WHERE id = $2 AND usuario_id = $3 RETURNING *",
        [nome, id, usuario_id]
    )
    return resultado.rows
}

async function excluirCategoria(event, id, usuario_id) {
    const resultado = await db.query(
        "DELETE FROM categorias WHERE id = $1 AND usuario_id = $2 RETURNING *",
        [id, usuario_id]
    )
    return resultado.rows
}

module.exports = {
    listarCategorias,
    criarCategoria,
    atualizarCategoria,
    excluirCategoria
}