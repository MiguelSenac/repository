const email = document.getElementById('email')
const senha = document.getElementById('senha')
const btnLogin = document.getElementById('btn-login')
const msg = document.getElementById('msg')

btnLogin.addEventListener('click', validarLogin)

const linkCadastro = document.getElementById('link-cadastro')

async function validarLogin() {
    const retorno = await window.financasAPI.validarLogin(email.value, senha.value) 
    console.log('Retorno do login:', retorno)
    if (retorno && retorno.id) {
        window.localStorage.setItem('usuario_id', retorno.id)
        window.localStorage.setItem('usuario_tipo', retorno.tipo)
        if(retorno.tipo == "admin"){
            console.log('ID salvo:', window.localStorage.getItem('usuario_id'))
            await window.janelaAPI.createAdminWindow()
        }
        else{
            await window.janelaAPI.createUserWindow()
        }
}
    else {
        msg.textContent = 'DEU RED'
        msg.style.color = 'red'
    }
}

    
linkCadastro.addEventListener('click', function(event) {
    event.preventDefault()
    window.location.href = 'cadastro.html'
})