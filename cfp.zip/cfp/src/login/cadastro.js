const email = document.getElementById('email')
const senha = document.getElementById('senha')
const nome = document.getElementById('nome')
const btnCadastrar = document.getElementById('btn-cadastrar')
const msg = document.getElementById('msg')

btnCadastrar.addEventListener('click', async () => {
    if (!email.value || !senha.value || !nome.value) {
        msg.textContent = 'Preencha todos os campos.'
        msg.style.color = 'red'
        return
    }
    const sucesso = await window.financasAPI.cadastrarUsuario(email.value, senha.value, nome.value)
    if (sucesso) {
        msg.textContent = 'Usuário cadastrado! Faça login.'
        msg.style.color = 'green'
        email.value = ''
        senha.value = ''
        nome.value = ''
    } else {
        msg.textContent = 'DEU RED'
        msg.style.color = 'red'
    }
})