const db = require('../../db')

async function validarLogin(event, email, senha){
    const resultado = await db.query("SELECT * FROM usuarios WHERE email = $1 AND senha = $2",[email, senha])
    if (resultado.rows.length > 0) {
        return resultado.rows[0]
    }
    else {
        return false
    }

}

async function cadastrarUsuario(event, email, senha, nome) {
    await db.query("INSERT INTO usuarios (email, senha, nome) VALUES ($1, $2, $3)", [email, senha, nome])
    return true
}


module.exports = {
    validarLogin,
    cadastrarUsuario
}