const {listarContas, criarConta, atualizarConta, excluirConta} = require('./src/conta/contaDB')
const {listarTransacoes, criarTransacao, atualizarTransacao, excluirTransacao, buscarTransacoesPorIdConta} = require('./src/transacao/transacaoDB')
const {listarCategorias, criarCategoria, atualizarCategoria, excluirCategoria} = require('./src/categoria/categoriaDB')
const { validarLogin, cadastrarUsuario } = require('./src/login/loginDB')
const { listarUsuarios, criarUsuario, atualizarUsuario, excluirUsuario } = require('./src/usuario/usuarioDB')
const{modalAbrirCategoria, modalAbrirTransacao, modalAbrirConta, modalAbrirUsuario} = require('./janelaModal') 
const{createAdminWindow, createUserWindow} = require('./janelaPrincipal')
const {ipcMain} = require('electron')

function registrarCategoriaHandlers() {
    ipcMain.handle('categoria-listar', listarCategorias)
    ipcMain.handle('categoria-criar', criarCategoria)
    ipcMain.handle('categoria-atualizar', atualizarCategoria)
    ipcMain.handle('categoria-excluir', excluirCategoria)
}

function registrarContaHandlers() {
    ipcMain.handle('conta-listar', listarContas)
    ipcMain.handle('conta-criar', criarConta)
    ipcMain.handle('conta-atualizar', atualizarConta)
    ipcMain.handle('conta-excluir', excluirConta)
}

function registrarTransacaoHandlers() {
    ipcMain.handle('transacao-listar', listarTransacoes)
    ipcMain.handle('transacao-criar', criarTransacao)
    ipcMain.handle('transacao-atualizar', atualizarTransacao)
    ipcMain.handle('transacao-excluir', excluirTransacao)
    ipcMain.handle('buscar-transacoes-por-id-conta', buscarTransacoesPorIdConta)
}


function registrarUsuarioHandlers() {
    ipcMain.handle('usuario-listar', listarUsuarios)
    ipcMain.handle('usuario-criar', criarUsuario)
    ipcMain.handle('usuario-atualizar', atualizarUsuario)
    ipcMain.handle('usuario-excluir', excluirUsuario)
}


function registrarLoginHandlers() {
    ipcMain.handle('validar-login', validarLogin)
    ipcMain.handle('cadastrar-usuario', cadastrarUsuario)
}

function registrarJanelas(){
    ipcMain.on('modal-abrir-categoria', modalAbrirCategoria)
    ipcMain.on('modal-abrir-transacao', modalAbrirTransacao)
    ipcMain.on('modal-abrir-conta', modalAbrirConta)
    ipcMain.on('janela-admin-criar', createAdminWindow)
    ipcMain.on('janela-user-criar', createUserWindow)
    ipcMain.on('modal-abrir-usuario', modalAbrirUsuario) 
}

function registrarListeners() {
    registrarCategoriaHandlers()
    registrarContaHandlers()
    registrarTransacaoHandlers()
    registrarLoginHandlers()
    registrarUsuarioHandlers()
    registrarJanelas()
    
}

module.exports = {
    registrarListeners
}


